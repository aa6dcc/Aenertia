# Lambda function to store file metadata in DynamoDB after S3 upload.

import json

def lambda_handler(event, context):
    """
    Lambda entry point to process metadata.
    Expects event like:
    {
        "fileName": "my_test.txt",
        "bucket": "aenershark-uploads",
        "path": "uploads/my_test.txt",
        "metadata": {
            "battery_level": 9.5,
            "timestamp": "2025-06-05T12:00:00Z"
        }
    }
    """
    print("🔧 Event received:", json.dumps(event, indent=2))

    battery_level = None
    try:
        battery_level = event["metadata"]["battery_level"]
    except (KeyError, TypeError):
        return {
            "statusCode": 400,
            "body": json.dumps("Invalid input: missing metadata.battery_level")
        }

    response_message = "✅ Battery level OK"
    if battery_level < 10:
        response_message = f"⚠️ WARNING: Battery low ({battery_level}%)"

    return {
        "statusCode": 200,
        "body": json.dumps(response_message)
    }
